package com.facturation.repository;

import com.facturation.model.Client;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface ClientRepository extends MongoRepository<Client, String> {
    Optional<Client> findByLogin(String login);

    List<Client> findByNomContainingIgnoreCaseOrTelContaining(String nom, String tel);
}
