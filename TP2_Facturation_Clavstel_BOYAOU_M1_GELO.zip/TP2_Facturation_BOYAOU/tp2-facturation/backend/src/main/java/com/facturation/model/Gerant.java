package com.facturation.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/** Gerant(Id, nom, login, password) - le mot de passe est stocke chiffre (BCrypt). */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "gerants")
public class Gerant {
    @Id
    private String id;
    private String nom;
    private String login;
    private String password;
}
