package com.facturation.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Client(Idclient, nom, tel) + login/password : necessaires pour que
 * le client puisse se connecter et consulter ses factures (TP2).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "clients")
public class Client {
    @Id
    private String id;

    @NotBlank(message = "Le nom est obligatoire")
    private String nom;

    private String tel;

    @NotBlank(message = "Le login est obligatoire")
    private String login;

    /** Jamais renvoye au frontend (ecriture seule). */
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String password;
}
