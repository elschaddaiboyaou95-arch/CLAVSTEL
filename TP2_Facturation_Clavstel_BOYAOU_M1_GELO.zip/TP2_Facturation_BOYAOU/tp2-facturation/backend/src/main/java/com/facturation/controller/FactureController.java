package com.facturation.controller;

import com.facturation.model.Client;
import com.facturation.model.Facture;
import com.facturation.model.FactureView;
import com.facturation.repository.ClientRepository;
import com.facturation.repository.FactureRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/** CRUD + recherche des factures (gerant) et consultation par le client. */
@RestController
@RequestMapping("/api/factures")
@RequiredArgsConstructor
public class FactureController {

    private final FactureRepository factures;
    private final ClientRepository clients;

    private Map<String, String> clientNames() {
        return clients.findAll().stream().collect(Collectors.toMap(Client::getId, Client::getNom));
    }

    private FactureView view(Facture f, Map<String, String> names) {
        return new FactureView(f.getId(), f.getMontant(), f.getObjet(), f.getIdClient(),
                names.getOrDefault(f.getIdClient(), "(client supprime)"), f.getDate());
    }

    /** Gerant : toutes les factures, avec recherche par objet, client ou numero. */
    @GetMapping
    public List<FactureView> list(@RequestParam(defaultValue = "") String q) {
        Map<String, String> names = clientNames();
        String t = q.trim().toLowerCase();
        return factures.findAll().stream()
                .map(f -> view(f, names))
                .filter(v -> t.isEmpty()
                        || v.objet().toLowerCase().contains(t)
                        || v.clientNom().toLowerCase().contains(t)
                        || v.id().toLowerCase().contains(t))
                .toList();
    }

    /** Client connecte : uniquement ses propres factures (id lu dans le JWT). */
    @GetMapping("/mes-factures")
    public List<FactureView> mine(Authentication auth) {
        String clientId = auth.getName();
        Map<String, String> names = clientNames();
        return factures.findByIdClient(clientId).stream().map(f -> view(f, names)).toList();
    }

    @GetMapping("/{id}")
    public FactureView get(@PathVariable String id) {
        Facture f = factures.findById(id).orElseThrow(this::notFound);
        return view(f, clientNames());
    }

    @PostMapping
    public ResponseEntity<FactureView> create(@Valid @RequestBody Facture f) {
        Client c = clients.findById(f.getIdClient())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Client introuvable"));
        f.setId(null);
        if (f.getDate() == null) f.setDate(LocalDate.now());
        Facture saved = factures.save(f);
        return ResponseEntity.status(HttpStatus.CREATED).body(view(saved, Map.of(c.getId(), c.getNom())));
    }

    @PutMapping("/{id}")
    public FactureView update(@PathVariable String id, @Valid @RequestBody Facture data) {
        Facture existing = factures.findById(id).orElseThrow(this::notFound);
        Client c = clients.findById(data.getIdClient())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Client introuvable"));
        existing.setMontant(data.getMontant());
        existing.setObjet(data.getObjet());
        existing.setIdClient(data.getIdClient());
        if (data.getDate() != null) existing.setDate(data.getDate());
        return view(factures.save(existing), Map.of(c.getId(), c.getNom()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        if (!factures.existsById(id)) throw notFound();
        factures.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private ResponseStatusException notFound() {
        return new ResponseStatusException(HttpStatus.NOT_FOUND, "Facture introuvable");
    }
}
