package com.facturation.config;

import com.facturation.model.Client;
import com.facturation.model.Facture;
import com.facturation.model.Gerant;
import com.facturation.repository.ClientRepository;
import com.facturation.repository.FactureRepository;
import com.facturation.repository.GerantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

/** Donnees de demonstration creees au premier demarrage (base vide). */
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final GerantRepository gerants;
    private final ClientRepository clients;
    private final FactureRepository factures;
    private final PasswordEncoder encoder;

    @Override
    public void run(String... args) {
        if (gerants.count() == 0) {
            gerants.save(new Gerant(null, "Administrateur", "admin", encoder.encode("admin123")));
        }
        if (clients.count() == 0) {
            Client a = clients.save(new Client(null, "Moussa Diop", "771234567", "moussa", encoder.encode("client123")));
            Client b = clients.save(new Client(null, "Awa Ndiaye", "781112233", "awa", encoder.encode("client123")));
            Client c = clients.save(new Client(null, "Cheikh Fall", "765554433", "cheikh", encoder.encode("client123")));
            factures.save(new Facture(null, 150000.0, "Achat de materiel informatique", a.getId(), LocalDate.now().minusDays(12)));
            factures.save(new Facture(null, 45000.0, "Maintenance reseau", a.getId(), LocalDate.now().minusDays(5)));
            factures.save(new Facture(null, 98500.0, "Licence logicielle annuelle", b.getId(), LocalDate.now().minusDays(8)));
            factures.save(new Facture(null, 27500.0, "Formation utilisateurs", c.getId(), LocalDate.now().minusDays(2)));
        }
    }
}
