package com.facturation.controller;

import com.facturation.model.Client;
import com.facturation.repository.ClientRepository;
import com.facturation.repository.FactureRepository;
import com.facturation.repository.GerantRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

/** CRUD + recherche des clients (reserve au gerant). */
@RestController
@RequestMapping("/api/clients")
@RequiredArgsConstructor
public class ClientController {

    private final ClientRepository clients;
    private final FactureRepository factures;
    private final GerantRepository gerants;
    private final PasswordEncoder encoder;

    @GetMapping
    public List<Client> list(@RequestParam(defaultValue = "") String q) {
        String term = q.trim();
        return term.isEmpty() ? clients.findAll()
                : clients.findByNomContainingIgnoreCaseOrTelContaining(term, term);
    }

    @GetMapping("/{id}")
    public Client get(@PathVariable String id) {
        return clients.findById(id).orElseThrow(this::notFound);
    }

    @PostMapping
    public ResponseEntity<Client> create(@Valid @RequestBody Client c) {
        if (c.getPassword() == null || c.getPassword().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Le mot de passe est obligatoire");
        }
        checkLoginFree(c.getLogin(), null);
        c.setId(null);
        c.setPassword(encoder.encode(c.getPassword()));
        return ResponseEntity.status(HttpStatus.CREATED).body(clients.save(c));
    }

    @PutMapping("/{id}")
    public Client update(@PathVariable String id, @Valid @RequestBody Client data) {
        Client existing = clients.findById(id).orElseThrow(this::notFound);
        checkLoginFree(data.getLogin(), id);
        existing.setNom(data.getNom());
        existing.setTel(data.getTel());
        existing.setLogin(data.getLogin());
        if (data.getPassword() != null && !data.getPassword().isBlank()) {
            existing.setPassword(encoder.encode(data.getPassword()));
        }
        return clients.save(existing);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        if (!clients.existsById(id)) throw notFound();
        factures.deleteByIdClient(id);   // suppression en cascade des factures du client
        clients.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private void checkLoginFree(String login, String selfId) {
        boolean usedByGerant = gerants.findByLogin(login).isPresent();
        boolean usedByOther = clients.findByLogin(login)
                .filter(x -> !x.getId().equals(selfId)).isPresent();
        if (usedByGerant || usedByOther) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Ce login est deja utilise");
        }
    }

    private ResponseStatusException notFound() {
        return new ResponseStatusException(HttpStatus.NOT_FOUND, "Client introuvable");
    }
}
