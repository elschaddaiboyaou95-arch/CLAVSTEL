package com.facturation.repository;

import com.facturation.model.Facture;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface FactureRepository extends MongoRepository<Facture, String> {
    List<Facture> findByIdClient(String idClient);

    void deleteByIdClient(String idClient);
}
