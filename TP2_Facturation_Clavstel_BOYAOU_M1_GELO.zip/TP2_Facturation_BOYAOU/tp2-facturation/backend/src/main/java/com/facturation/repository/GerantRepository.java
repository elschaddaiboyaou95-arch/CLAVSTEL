package com.facturation.repository;

import com.facturation.model.Gerant;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface GerantRepository extends MongoRepository<Gerant, String> {
    Optional<Gerant> findByLogin(String login);
}
