package com.facturation.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;

/** Facture(Idfact, montant, objet, IdClient) + date d'emission. */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "factures")
public class Facture {
    @Id
    private String id;

    @NotNull(message = "Le montant est obligatoire")
    @Positive(message = "Le montant doit etre positif")
    private Double montant;

    @NotBlank(message = "L'objet est obligatoire")
    private String objet;

    @NotBlank(message = "Le client est obligatoire")
    private String idClient;

    private LocalDate date;
}
