package com.facturation.controller;

import com.facturation.repository.ClientRepository;
import com.facturation.repository.GerantRepository;
import com.facturation.security.JwtService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    public record LoginRequest(@NotBlank(message = "Login obligatoire") String login,
                               @NotBlank(message = "Mot de passe obligatoire") String password) {}

    public record LoginResponse(String token, String role, String nom, String userId) {}

    private final GerantRepository gerants;
    private final ClientRepository clients;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    @PostMapping("/login")
    public LoginResponse login(@Valid @RequestBody LoginRequest req) {
        var gerant = gerants.findByLogin(req.login());
        if (gerant.isPresent() && encoder.matches(req.password(), gerant.get().getPassword())) {
            var g = gerant.get();
            return new LoginResponse(jwt.generate(g.getLogin(), "GERANT", g.getId()), "GERANT", g.getNom(), g.getId());
        }
        var client = clients.findByLogin(req.login());
        if (client.isPresent() && encoder.matches(req.password(), client.get().getPassword())) {
            var c = client.get();
            return new LoginResponse(jwt.generate(c.getLogin(), "CLIENT", c.getId()), "CLIENT", c.getNom(), c.getId());
        }
        throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Login ou mot de passe incorrect");
    }
}
