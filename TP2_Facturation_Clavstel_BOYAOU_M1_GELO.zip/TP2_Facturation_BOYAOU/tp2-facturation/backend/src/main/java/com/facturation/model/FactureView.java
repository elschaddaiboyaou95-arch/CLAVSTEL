package com.facturation.model;

import java.time.LocalDate;

/** Facture enrichie du nom du client, renvoyee au frontend. */
public record FactureView(String id, Double montant, String objet,
                          String idClient, String clientNom, LocalDate date) {
}
