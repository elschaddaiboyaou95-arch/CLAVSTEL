package com.facturation.controller;

import com.facturation.model.Client;
import com.facturation.repository.ClientRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** CRUD + recherche des clients. */
@Controller
@RequestMapping("/clients")
@RequiredArgsConstructor
public class ClientController {

    private final ClientRepository clients;

    @GetMapping
    public String list(@RequestParam(defaultValue = "") String q, Model model) {
        String term = q.trim();
        model.addAttribute("clients", term.isEmpty()
                ? clients.findAll(Sort.by("nom"))
                : clients.findByNomContainingIgnoreCaseOrTelContaining(term, term));
        model.addAttribute("q", q);
        return "clients";
    }

    @GetMapping("/nouveau")
    public String nouveau(Model model) {
        model.addAttribute("client", new Client());
        return "client-form";
    }

    @GetMapping("/{id}/modifier")
    public String modifier(@PathVariable Long id, Model model, RedirectAttributes ra) {
        return clients.findById(id).map(c -> {
            model.addAttribute("client", c);
            return "client-form";
        }).orElseGet(() -> {
            ra.addFlashAttribute("error", "Client introuvable");
            return "redirect:/clients";
        });
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("client") Client form, BindingResult result,
                       RedirectAttributes ra) {
        if (result.hasErrors()) {
            return "client-form";
        }
        boolean creation = form.getIdClient() == null;
        Client client = creation ? form : clients.findById(form.getIdClient()).orElseThrow();
        if (!creation) {            // on ne recopie que les champs modifiables
            client.setNom(form.getNom());
            client.setTel(form.getTel());
        }
        clients.save(client);
        ra.addFlashAttribute("success", creation ? "Client ajouté avec succès" : "Client modifié avec succès");
        return "redirect:/clients";
    }

    @PostMapping("/{id}/supprimer")
    public String supprimer(@PathVariable Long id, RedirectAttributes ra) {
        if (clients.existsById(id)) {
            clients.deleteById(id);      // supprime aussi ses factures (cascade)
            ra.addFlashAttribute("success", "Client et factures associées supprimés");
        } else {
            ra.addFlashAttribute("error", "Client introuvable");
        }
        return "redirect:/clients";
    }
}
