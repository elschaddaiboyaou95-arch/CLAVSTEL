package com.facturation.repository;

import com.facturation.model.Client;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ClientRepository extends JpaRepository<Client, Long> {
    // Recherche par nom (sans tenir compte de la casse) ou par telephone
    List<Client> findByNomContainingIgnoreCaseOrTelContaining(String nom, String tel);
}
