package com.facturation.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Gerant(Id, nom, login, password) - mot de passe stocke chiffre (BCrypt). */
@Entity
@Table(name = "gerant")
@Getter @Setter @NoArgsConstructor
public class Gerant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(nullable = false, length = 100)
    private String nom;

    @Column(nullable = false, unique = true, length = 50)
    private String login;

    @Column(nullable = false, length = 100)
    private String password;

    public Gerant(String nom, String login, String password) {
        this.nom = nom;
        this.login = login;
        this.password = password;
    }
}
