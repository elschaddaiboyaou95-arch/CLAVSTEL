package com.facturation.config;

import com.facturation.model.Client;
import com.facturation.model.Facture;
import com.facturation.model.Gerant;
import com.facturation.repository.ClientRepository;
import com.facturation.repository.FactureRepository;
import com.facturation.repository.GerantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** Cree le gerant par defaut et des donnees de demonstration si la base est vide. */
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final GerantRepository gerants;
    private final ClientRepository clients;
    private final FactureRepository factures;
    private final PasswordEncoder encoder;

    @Override
    public void run(String... args) {
        if (gerants.count() == 0) {
            gerants.save(new Gerant("Administrateur", "admin", encoder.encode("admin123")));
        }
        if (clients.count() == 0) {
            Client a = clients.save(new Client("Moussa Diop", "771234567"));
            Client b = clients.save(new Client("Awa Ndiaye", "781112233"));
            Client c = clients.save(new Client("Cheikh Fall", "765554433"));
            factures.save(new Facture(150000.0, "Achat de materiel informatique", a));
            factures.save(new Facture(45000.0, "Maintenance reseau", a));
            factures.save(new Facture(98500.0, "Licence logicielle annuelle", b));
            factures.save(new Facture(27500.0, "Formation utilisateurs", c));
        }
    }
}
