package com.facturation.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/** Client(Idclient, nom, tel). Un client possede plusieurs factures. */
@Entity
@Table(name = "client")
@Getter @Setter @NoArgsConstructor
public class Client {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idclient")
    private Long idClient;

    @NotBlank(message = "Le nom est obligatoire")
    @Column(nullable = false, length = 100)
    private String nom;

    @Pattern(regexp = "^$|^[0-9+ ]{6,20}$", message = "Numéro de téléphone invalide")
    @Column(length = 20)
    private String tel;

    // Suppression d'un client => suppression de ses factures
    @OneToMany(mappedBy = "client", cascade = CascadeType.REMOVE)
    private List<Facture> factures = new ArrayList<>();

    public Client(String nom, String tel) {
        this.nom = nom;
        this.tel = tel;
    }
}
