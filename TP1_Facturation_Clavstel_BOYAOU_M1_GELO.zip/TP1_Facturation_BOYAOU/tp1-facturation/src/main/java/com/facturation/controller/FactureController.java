package com.facturation.controller;

import com.facturation.model.Client;
import com.facturation.model.Facture;
import com.facturation.repository.ClientRepository;
import com.facturation.repository.FactureRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** CRUD + recherche des factures. */
@Controller
@RequestMapping("/factures")
@RequiredArgsConstructor
public class FactureController {

    private final FactureRepository factures;
    private final ClientRepository clients;

    @GetMapping
    public String list(@RequestParam(defaultValue = "") String q, Model model) {
        String term = q.trim();
        model.addAttribute("factures", term.isEmpty()
                ? factures.findAll(Sort.by(Sort.Direction.DESC, "idFact"))
                : factures.search(term));
        model.addAttribute("q", q);
        return "factures";
    }

    @GetMapping("/nouveau")
    public String nouveau(Model model) {
        Facture f = new Facture();
        f.setClient(new Client());
        return formulaire(f, model);
    }

    @GetMapping("/{id}/modifier")
    public String modifier(@PathVariable Long id, Model model, RedirectAttributes ra) {
        return factures.findById(id).map(f -> formulaire(f, model)).orElseGet(() -> {
            ra.addFlashAttribute("error", "Facture introuvable");
            return "redirect:/factures";
        });
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("facture") Facture form, BindingResult result,
                       Model model, RedirectAttributes ra) {
        Long clientId = form.getClient() != null ? form.getClient().getIdClient() : null;
        Client client = clientId == null ? null : clients.findById(clientId).orElse(null);
        if (client == null) {
            result.rejectValue("client", "client.required", "Veuillez choisir un client");
        }
        if (result.hasErrors()) {
            if (form.getClient() == null) form.setClient(new Client());
            return formulaire(form, model);
        }
        boolean creation = form.getIdFact() == null;
        Facture facture = creation ? form : factures.findById(form.getIdFact()).orElseThrow();
        facture.setMontant(form.getMontant());
        facture.setObjet(form.getObjet());
        facture.setClient(client);
        factures.save(facture);
        ra.addFlashAttribute("success", creation ? "Facture ajoutée avec succès" : "Facture modifiée avec succès");
        return "redirect:/factures";
    }

    @PostMapping("/{id}/supprimer")
    public String supprimer(@PathVariable Long id, RedirectAttributes ra) {
        if (factures.existsById(id)) {
            factures.deleteById(id);
            ra.addFlashAttribute("success", "Facture supprimée");
        } else {
            ra.addFlashAttribute("error", "Facture introuvable");
        }
        return "redirect:/factures";
    }

    private String formulaire(Facture facture, Model model) {
        model.addAttribute("facture", facture);
        model.addAttribute("clients", clients.findAll(Sort.by("nom")));
        return "facture-form";
    }
}
