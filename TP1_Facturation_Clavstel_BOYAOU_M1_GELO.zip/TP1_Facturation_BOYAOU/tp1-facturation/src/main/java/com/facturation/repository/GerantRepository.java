package com.facturation.repository;

import com.facturation.model.Gerant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface GerantRepository extends JpaRepository<Gerant, Long> {
    Optional<Gerant> findByLogin(String login);
}
