package com.facturation.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Facture(Idfact, montant, objet, IdClient). IdClient est la cle etrangere vers Client. */
@Entity
@Table(name = "facture")
@Getter @Setter @NoArgsConstructor
public class Facture {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idfact")
    private Long idFact;

    @NotNull(message = "Le montant est obligatoire")
    @Positive(message = "Le montant doit être positif")
    @Column(nullable = false)
    private Double montant;

    @NotBlank(message = "L'objet est obligatoire")
    @Column(nullable = false)
    private String objet;

    @ManyToOne(optional = false)
    @JoinColumn(name = "idclient", nullable = false)
    private Client client;

    public Facture(Double montant, String objet, Client client) {
        this.montant = montant;
        this.objet = objet;
        this.client = client;
    }
}
