package com.facturation.security;

import com.facturation.model.Gerant;
import com.facturation.repository.GerantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/** Fournit a Spring Security le gerant correspondant au login saisi. */
@Service
@RequiredArgsConstructor
public class GerantUserDetailsService implements UserDetailsService {

    private final GerantRepository gerants;

    @Override
    public UserDetails loadUserByUsername(String login) throws UsernameNotFoundException {
        Gerant g = gerants.findByLogin(login)
                .orElseThrow(() -> new UsernameNotFoundException("Gérant introuvable : " + login));
        return User.withUsername(g.getLogin()).password(g.getPassword()).roles("GERANT").build();
    }
}
