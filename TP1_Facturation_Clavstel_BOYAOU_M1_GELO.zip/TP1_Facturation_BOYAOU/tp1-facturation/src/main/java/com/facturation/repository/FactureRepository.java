package com.facturation.repository;

import com.facturation.model.Facture;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FactureRepository extends JpaRepository<Facture, Long> {

    // Recherche par objet ou par nom du client
    @Query("select f from Facture f where lower(f.objet) like lower(concat('%', :q, '%')) "
         + "or lower(f.client.nom) like lower(concat('%', :q, '%')) order by f.idFact desc")
    List<Facture> search(@Param("q") String q);
}
